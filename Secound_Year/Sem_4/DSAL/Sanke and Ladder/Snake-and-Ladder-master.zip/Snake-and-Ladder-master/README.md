# Snake-and-Ladder
Snake and ladder is a simple game consists of snakes and ladders. The object of the game is to navigate one's game piece, according to die rolls, from the start (bottom square) to the finish (top square), helped or hindered by ladders and snakes respectively.

This is a python based version of this game which consist of GUI which is designed using Python's tkinter library

#### Functions: 
###### def gamePlay(self):
###### def create_peice(self):
###### def peices(self, move, turn):
###### def diceMove(self, position, turn):
###### def get_choice(self, value):
###### def startGame(self):
